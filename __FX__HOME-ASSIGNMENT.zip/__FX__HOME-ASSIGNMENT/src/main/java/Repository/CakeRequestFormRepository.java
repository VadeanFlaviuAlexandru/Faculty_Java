package Repository;
import Domain.*;




//extends keyword is used to extend the functionality of the parent class to the subclass
public class CakeRequestFormRepository extends AbstractRepository<CakeRequestForm, Integer>{
    public CakeRequestFormRepository() {}
}

