package Domain;



//interface with methods
public interface Identifiable <Tid>{
    Tid getID();
    void setID(Tid id);
}
